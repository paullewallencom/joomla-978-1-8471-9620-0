<?php
defined('_JEXEC') or die;
?>
<div class="goodcook<?php echo $moduleclass_sfx; ?>">
	<?php
    foreach ($data as $class => $item) {
		if ($class == "item") {
			echo "<h4>".$item->title."</h4>";
			echo "<div>".$item->recipe."</div>";
			continue;
		}
    ?>
        <div class="<?php echo $class; ?>"><?php echo $item; ?></div>
    <?php 
    }
    ?>
</div>
