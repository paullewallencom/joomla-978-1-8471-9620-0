<?php

defined('_JEXEC') or die('Restricted access');

require_once __DIR__ . '/helper.php';

$data = array();
$data['text'] = htmlspecialchars($params->get('foo_text'));
$data['textarea'] = htmlspecialchars($params->get('foo_textarea'));
$data['texteditor'] = $params->get('foo_editor');
$data['item'] = modFooHelper::getItem($params->get('recipe'));

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require JModuleHelper::getLayoutPath('mod_foo', $params->get('layout', 'default'));
