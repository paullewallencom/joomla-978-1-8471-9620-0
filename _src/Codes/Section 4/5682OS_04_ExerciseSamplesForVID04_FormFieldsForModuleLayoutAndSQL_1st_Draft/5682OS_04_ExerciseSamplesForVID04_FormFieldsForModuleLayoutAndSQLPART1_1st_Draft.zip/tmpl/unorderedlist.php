<?php
defined('_JEXEC') or die;
?>
<div class="goodcook<?php echo $moduleclass_sfx; ?>">
	<?php
    foreach ($data as $class => $item) {

		if ($class == "items") {
			echo "<ul>";
			foreach ($item as $itm) {
				echo "<li>".$itm->linkitem."</li>";
			}
			echo "</ul>";
			continue;
		}
    ?>
        <div class="<?php echo $class; ?>"><?php echo $item; ?></div>
    <?php 
    }
    ?>
</div>
